# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.19.5
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Encoding Categorical Features
#
# [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/Ujjwal091/ai-ml-course/blob/main/modules/data-preprocessing/encoding/notes.ipynb)
#
# *A general-purpose preprocessing step: turning text categories into numbers a model can actually use, without
# accidentally inventing an ordering or a magnitude that isn't real.*
#

# %% [markdown]
# ## 1. Why categorical features need encoding
#
# Most ML algorithms are built on arithmetic — dot products, distances, gradients — none of which are defined on
# the string `"europe"`. Before a categorical column can enter a model, it has to become numbers. The dataset for
# this notebook: the Auto MPG dataset, where `origin` (`usa` / `europe` / `japan`) is exactly this kind of column.
#

# %%
import os
import pandas as pd

MPG_URL = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/mpg.csv"
MPG_PATH = "data/auto-mpg.csv"

if not os.path.exists(MPG_PATH):
    os.makedirs("data", exist_ok=True)
    pd.read_csv(MPG_URL).to_csv(MPG_PATH, index=False)

df = pd.read_csv(MPG_PATH)
df['origin'].value_counts()

# %% [markdown]
# ## 2. The naive approach — and why it's wrong
#
# The tempting shortcut is to just assign each category a number: `usa=1`, `europe=2`, `japan=3`. That's **label
# (ordinal) encoding**, and it's only correct when the categories have a genuine order — `low < medium < high`,
# say. Here they don't: nothing about "japan" makes it "3 times" anything relative to "usa".
#
# A model fed `origin` this way would silently learn that `japan` (3) has three times the numeric weight of `usa`
# (1) in any linear term — an ordering the data never actually implied. That's a real, common bug, not a
# theoretical one.
#

# %%
label_map = {'usa': 1, 'europe': 2, 'japan': 3}
df['origin_label'] = df['origin'].map(label_map)
df[['origin', 'origin_label']].drop_duplicates()

# %% [markdown]
# > **When label encoding *is* fine:** when the categories genuinely have an order the model should respect — a
# > `size` column with `small < medium < large`, for instance. `origin` has no such order, which is exactly why
# > this approach is wrong here.
#

# %% [markdown]
# ## 3. One-Hot Encoding — the general-purpose fix
#
# Instead of one column with an implied order, create one binary column *per category*. Each row gets a 1 in
# exactly one of them:
#
# | origin | origin_usa | origin_europe | origin_japan |
# |---|---|---|---|
# | usa | 1 | 0 | 0 |
# | europe | 0 | 1 | 0 |
# | japan | 0 | 0 | 1 |
#
# No column implies more or less than any other — the model treats all three as independent, equal-footing
# signals.
#

# %%
one_hot = pd.get_dummies(df[['origin']], columns=['origin'], dtype=int)
one_hot.drop_duplicates()

# %% [markdown]
# ## 4. The dummy variable trap
#
# With 3 categories, knowing any 2 of the 3 one-hot columns tells you the 3rd for free — if a row isn't `usa` and
# isn't `europe`, it must be `japan`. That means one column carries no additional information: it's a perfect
# linear combination of the other two ($\text{origin\_japan} = 1 - \text{origin\_usa} - \text{origin\_europe}$),
# which is exactly the kind of multicollinearity that destabilizes a regression model's coefficients.
#
# **The fix:** always drop one category's column — it becomes the implicit "baseline" that every other category
# is compared against.
#

# %%
one_hot_safe = pd.get_dummies(df[['origin']], columns=['origin'], drop_first=True, dtype=int)
one_hot_safe.drop_duplicates()

# %% [markdown]
# `origin_europe` is now the baseline: a row of all zeros in the remaining columns means "europe", and every
# coefficient the model later learns for `origin_usa` or `origin_japan` is interpreted *relative to europe*.
#

# %% [markdown]
# ## 5. Beyond one-hot — a quick map
#
# | Encoding | Use when | Watch out for |
# |---|---|---|
# | Label / ordinal | Categories have a true order | Never use on unordered categories |
# | One-hot | Unordered categories, a manageable number of them | Column count explodes with high-cardinality features (hundreds of categories); always drop one column |
# | Target / mean encoding | Very high-cardinality categoricals (e.g. hundreds of car models) | Leaks target information if not done inside a proper train/test split |
#
# ## 6. Summary
#
# - Never feed raw category strings — or naively-assigned integers — into a model unless the categories have a
#   genuine order.
# - **One-Hot Encoding** is the safe general-purpose default: one binary column per category, with one column
#   dropped to avoid the dummy variable trap.
# - For categoricals with very many distinct values, plain one-hot stops being practical — that's when target
#   encoding or embeddings become worth the added complexity.
#
# **Where this leads next:** encoded and scaled data (see [Feature Scaling](../feature-scaling/notes.ipynb)) is
# what most model-fitting notebooks in this repo assume as their starting point.
#
